from objloader import OBJ
__all__ = ['OBJ']
